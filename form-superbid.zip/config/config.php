<?php

$api_config = array(
    "dropboxKey"   => 'pskz2u4wsfpwr81',
    "dropboxSecret" => 'lrnk289ph4z7f0f',
    "dropboxToken"  => '_G_W5xxbk7sAAAAAAAAAASLYalbj5W2DzfaByFg7JBnEYbZuiWZhNriOzQCm5QnT'
);